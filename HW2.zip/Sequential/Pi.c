#include <stdio.h>
#include <omp.h>
#include <time.h>
#define INT_MAX 2147483647

double compute_pi()
{
	double pi;
	const size_t N = 10000000;
	int circle_darts = 0;
	double start, end;
	
	omp_set_num_threads(2);

	start = omp_get_wtime();
	#pragma omp parallel shared(circle_darts)
	{
		int thread_id = omp_get_thread_num();

		unsigned int seed_x = 123456789 * (thread_id + 1);
		unsigned int seed_y = 123456780 * (thread_id + 1); 

		double x, y;
		#pragma omp for schedule(dynamic, N / 2) \
				reduction(+: circle_darts) \
				private(x, y)
		for (int i = 0; i < N; i++)
		{
			x = ((double) rand_r(&seed_x)) / (double) INT_MAX;
			y = ((double) rand_r(&seed_y)) / (double) INT_MAX;
	
			if (1 >  (x*x + y*y)) ++circle_darts;
			
		}
	}
	
	pi = 4 * ((double)circle_darts/N);
	
	end = omp_get_wtime();
	
        printf("parallel monte-carlo pi = %.8f, time = %f\n", pi, (double)(end - start));
	return pi;
}

int main()
{
    const size_t N = 10000000;
    int circle_darts = 0;
    double x, pi, sum = 0.;
    double pi_parallel = 0.;
    double start, end;
    
    start = omp_get_wtime();    

    unsigned int seed_x = 123456789;
    unsigned int seed_y = 123456780; 

    for (int i = 0; i < N; i++)
    {
	double x = ((double) rand_r(&seed_x)) / (double) INT_MAX;
	double y = ((double) rand_r(&seed_y)) / (double) INT_MAX;
	
	if (1 >  (x*x + y*y)) ++circle_darts;
			
    }

    pi = 4 * ((double) circle_darts / N);
    end = omp_get_wtime();

    printf("pi = %.8f, time = %f\n", pi, (double)(end - start));
    
    pi_parallel = compute_pi();
    	
    return 0;
}
