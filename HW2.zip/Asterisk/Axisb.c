//Jacobi method
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

double ** create_matrix(int N)
{	
	srand(time(NULL));
	double sum;

	// matrix initialization
	double **A = (double **)malloc(N*sizeof(double *));
	for (int i = 0; i < N; i++)
	{
		A[i] = (double *)malloc(N*sizeof(double));
	}

	//creating matrix
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			A[i][j] = rand() / (double) RAND_MAX;
		//	if (i == j) A[i][j] += N;
		}
	}

	//check matrix dominant condition
	for (int i = 0; i < N; i++)
	{
		sum = 0;
		for (int j = 0; j < N; j++)
		{
			if (i != j)
			{
				sum += A[i][j];
			}
			//printf("%.2f\t", A[i][j]);
		}
		A[i][i] += sum + 1;
		if (A[i][i] < sum) 
		{
			printf("Matrix is not diagonal dominant. Try again.\n");
			exit(-1);
		}
		//printf("\n");
	}
	return A;
}	
void free_matrix(double ** matrix, size_t N)
{
    for (int i = 0; i < N; ++i)
    {
        free(matrix[i]);
    }

    free(matrix);
}

double * create_vector(int N, double add)
{
	double *x = (double *)malloc(N*sizeof(double));
	for (int i = 0; i < N; i++)
	{
		x[i] = rand() / (double) RAND_MAX + add;
	}
	return x;
}	

double norm_error(double *x1, double *x2, int N)
{
	double err = 0;
	for (int i = 0; i < N; i++)
	{
		err += (x1[i] - x2[i])*(x1[i] - x2[i]);
	}
	return err;
}

//chto kuda
void copy(double *x1, double *x2, int N)
{
	for (int i = 0; i < N; i++)
	{
		x2[i] = x1[i];		
	}
}

int main()
{
	int N = 1000, count = 0;
	double **A, *b, *x, *x_out;
	double eps = 1e-4, sigma;
	double start, end;

	omp_set_num_threads(2);
	int chunk = N / 2;
	int j;
	
	A = create_matrix(N);
	b = create_vector(N, 1.);
	x = create_vector(N, 0.01);
	x_out = create_vector(N, 0.);
		
	start = omp_get_wtime();
	count = 0;

	while (norm_error(x, x_out, N) > eps)
	{	
		copy(x_out, x, N);
		//jacobi step
		for (int i = 0; i < N; i++)
		{
			sigma = 0;
			#pragma omp parallel for reduction(+: sigma) \
						schedule(dynamic, chunk) \
						private(j)
			for (j = 0; j < N; j++)
			{
				if (i != j)
				{
					sigma += A[i][j]*x[j];
				}
			}
			x_out[i] = 1./A[i][i]*(b[i] - sigma);
		}
		count++;
	}
	end = omp_get_wtime();
	
	printf("Error: %f\n", norm_error(x, x_out, N));
	printf("Time: %f\n", (double)(end - start));
	printf("Number of iteration: %d\n", count);

	free(x);
	free(x_out);
	free_matrix(A, N);
	return 0;
}
