#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include <time.h>

void free_matrix(double ** matrix, int N)
{
    for (int i = 0; i < N; ++i)
    {
        free(matrix[i]);
    }

    free(matrix);
}

double ** matrix_init(double a, double b, int N)
{
	// matrix with points
        double ** A = (double **) malloc(sizeof(double*)*N);
	
        for (int i = 0; i < N; i++)
        {
                A[i] = (double *)malloc(sizeof(double)*2);
        } 

        srand(time(NULL));

        for (int i = 0; i < N; i++)
        {
                A[i][0] = i * rand() / (double) RAND_MAX;
                A[i][1] = a * A[i][0] + b + rand() / (double) RAND_MAX;
        }
	return A;
}

void write_matrix(FILE *fp, double ** A, int N)
{
	for (int i = 0; i < N; i++)
	{
		fprintf(fp, "%f\t%f\n", A[i][0], A[i][1]);
	}
}

int main()
{
	// number of points
	int N = 1000, n_steps = 1000000;
	double a = 6., b = 5., step_size = 0.0001;
	double a_grad, b_grad, a_new, b_new;
	double ** A;
	//FILE *file_in, *file_out;
	double start, end;
	int i;

	printf("a = %f, b = %f\n", a, b);
	omp_set_num_threads(2);
	//file_in = fopen ("./in.txt", "a+");
	A = matrix_init(a, b, N);
	//write_matrix(file_in, A, N);
	
	srand(time(NULL));
	a_new = rand() / RAND_MAX;
	b_new = rand() / RAND_MAX;
	
	start = omp_get_wtime();

	for (int step = 0; step < n_steps; step++)
	{
		a_grad = 0.;
		b_grad = 0.;
		
		#pragma omp parallel for reduction(+: a_grad) \
					 reduction(+: b_grad) \
					 schedule(static) \
					 private(i)
		for (i = 0; i < N; i++)
		{
			a_grad += -2*(A[i][1] - a_new*A[i][0] - b_new)*A[i][0];
			b_grad += -2*(A[i][1] - a_new*A[i][0] - b_new);
		}
		
		a_new -= step_size*a_grad;
		b_new -= step_size*b_grad;

	}
	end = omp_get_wtime();
	printf("Calculated: a = %f, b = %f\n", a_new, b_new);
	printf("Time: %f\n", (double)(end - start));

	free_matrix(A, N);
	//fclose(file_in);
	return 0;
}
